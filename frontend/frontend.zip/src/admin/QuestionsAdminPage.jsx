import React, { useState, useEffect } from 'react';
import '../PTIS_App.css';

const QuestionsAdminPage = ({ onBack }) => {
  const [questions, setQuestions] = useState([]);
  const [standards, setStandards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [filterStandard, setFilterStandard] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [formData, setFormData] = useState({
    Question: '',
    Opt_A: '',
    Opt_B: '',
    Opt_C: '',
    Opt_D: '',
    Answer: '',
    Standard_List: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [questionsRes, standardsRes] = await Promise.all([
        fetch('http://localhost:3001/api/questions?standard=ALL'),
        fetch('http://localhost:3001/api/standards')
      ]);
      
      // Fetch questions from all standards
      const standardsData = await standardsRes.json();
      setStandards(standardsData);
      
      // Fetch all questions
      const allQuestions = [];
      for (const std of standardsData) {
        try {
          const res = await fetch(`http://localhost:3001/api/questions?standard=${encodeURIComponent(std.Standard_List)}`);
          const data = await res.json();
          allQuestions.push(...data);
        } catch (err) {
          console.error(`Error fetching questions for ${std.Standard_List}:`, err);
        }
      }
      
      setQuestions(allQuestions);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Failed to load questions data');
      setLoading(false);
    }
  };

  const filteredQuestions = questions.filter(q => {
    const matchesStandard = !filterStandard || q.Standard === filterStandard;
    const matchesSearch = !searchQuery || 
      q.Question?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.Opt_A?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.Opt_B?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.Opt_C?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.Opt_D?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStandard && matchesSearch;
  });

  const handleAdd = () => {
    setEditMode(false);
    setCurrentQuestion(null);
    setFormData({
      Question: '',
      Opt_A: '',
      Opt_B: '',
      Opt_C: '',
      Opt_D: '',
      Answer: 'A',
      Standard_List: standards[0]?.Standard_List || ''
    });
    setShowModal(true);
  };

  const handleEdit = (question) => {
    setEditMode(true);
    setCurrentQuestion(question.NO);
    setFormData({
      Question: question.Question,
      Opt_A: question.Opt_A,
      Opt_B: question.Opt_B,
      Opt_C: question.Opt_C,
      Opt_D: question.Opt_D,
      Answer: question.Answer,
      Standard_List: question.Standard
    });
    setShowModal(true);
  };

  const handleDelete = async (questionNo) => {
    if (!window.confirm('Are you sure you want to delete this question?')) {
      return;
    }

    try {
      const response = await fetch(`http://localhost:3001/api/questions/${questionNo}`, {
        method: 'DELETE'
      });
      
      if (!response.ok) throw new Error('Delete failed');
      alert('Question deleted successfully!');
      fetchData();
    } catch (error) {
      console.error('Error deleting question:', error);
      alert('Failed to delete question');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (editMode) {
        const response = await fetch(`http://localhost:3001/api/questions/${currentQuestion}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        
        if (!response.ok) throw new Error('Update failed');
        alert('Question updated successfully!');
      } else {
        const response = await fetch('http://localhost:3001/api/questions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        
        if (!response.ok) throw new Error('Create failed');
        alert('Question created successfully!');
      }

      setShowModal(false);
      fetchData();
    } catch (error) {
      console.error('Error saving question:', error);
      alert('Failed to save question');
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (loading) {
    return <div style={{ padding: '50px', textAlign: 'center' }}>Loading questions...</div>;
  }

  return (
    <div style={{ padding: '30px', maxWidth: '1400px', margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
          <button
            onClick={onBack}
            style={{
              padding: '10px 20px',
              backgroundColor: '#3498db',
              color: 'white',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold'
            }}
          >
            ← Back
          </button>
          <h2 style={{ margin: 0, color: '#2c3e50' }}>Questions Management</h2>
        </div>
        <button
          onClick={handleAdd}
          style={{
            padding: '12px 25px',
            backgroundColor: '#3498db',
            color: 'white',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            fontSize: '16px',
            fontWeight: 'bold'
          }}
        >
          + Add New Question
        </button>
      </div>

      {/* Filters */}
      <div style={{ backgroundColor: '#ecf0f1', padding: '20px', borderRadius: '10px', marginBottom: '20px' }}>
        <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
          <div style={{ flex: 1 }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold', fontSize: '14px' }}>
              Filter by Standard:
            </label>
            <select
              value={filterStandard}
              onChange={(e) => setFilterStandard(e.target.value)}
              style={{
                width: '100%',
                padding: '10px',
                border: '1px solid #bdc3c7',
                borderRadius: '5px',
                fontSize: '14px'
              }}
            >
              <option value="">All Standards</option>
              {standards.map(std => (
                <option key={std.Standard_List} value={std.Standard_List}>
                  {std.Standard_List}
                </option>
              ))}
            </select>
          </div>
          <div style={{ flex: 2 }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold', fontSize: '14px' }}>
              Search Questions:
            </label>
            <input
              type="text"
              placeholder="Search in question text or options..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: '10px',
                border: '1px solid #bdc3c7',
                borderRadius: '5px',
                fontSize: '14px'
              }}
            />
          </div>
          <div style={{ alignSelf: 'flex-end' }}>
            <button
              onClick={() => { setFilterStandard(''); setSearchQuery(''); }}
              style={{
                padding: '10px 20px',
                backgroundColor: '#95a5a6',
                color: 'white',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              Clear Filters
            </button>
          </div>
        </div>
        <div style={{ marginTop: '10px', fontSize: '14px', color: '#7f8c8d' }}>
          Showing {filteredQuestions.length} of {questions.length} questions
        </div>
      </div>

      {/* Questions Table */}
      <div style={{ backgroundColor: '#ecf0f1', padding: '20px', borderRadius: '10px' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', backgroundColor: 'white' }}>
            <thead>
              <tr style={{ backgroundColor: '#34495e', color: 'white' }}>
                <th style={{ padding: '15px', textAlign: 'left', border: '1px solid #bdc3c7', width: '60px' }}>NO</th>
                <th style={{ padding: '15px', textAlign: 'left', border: '1px solid #bdc3c7' }}>Question</th>
                <th style={{ padding: '15px', textAlign: 'left', border: '1px solid #bdc3c7', width: '150px' }}>Standard</th>
                <th style={{ padding: '15px', textAlign: 'left', border: '1px solid #bdc3c7', width: '80px' }}>Answer</th>
                <th style={{ padding: '15px', textAlign: 'center', border: '1px solid #bdc3c7', width: '180px' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredQuestions.map((question, index) => (
                <tr key={question.NO} style={{ borderBottom: '1px solid #bdc3c7' }}>
                  <td style={{ padding: '12px', border: '1px solid #bdc3c7' }}>{question.NO}</td>
                  <td style={{ padding: '12px', border: '1px solid #bdc3c7' }}>
                    <div style={{ fontWeight: 'bold', marginBottom: '8px' }}>{question.Question}</div>
                    <div style={{ fontSize: '13px', color: '#555', lineHeight: '1.6' }}>
                      <div><strong>A:</strong> {question.Opt_A}</div>
                      <div><strong>B:</strong> {question.Opt_B}</div>
                      <div><strong>C:</strong> {question.Opt_C}</div>
                      <div><strong>D:</strong> {question.Opt_D}</div>
                    </div>
                  </td>
                  <td style={{ padding: '12px', border: '1px solid #bdc3c7' }}>{question.Standard}</td>
                  <td style={{ padding: '12px', border: '1px solid #bdc3c7', textAlign: 'center', fontWeight: 'bold', color: '#27ae60' }}>
                    {question.Answer}
                  </td>
                  <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #bdc3c7' }}>
                    <button
                      onClick={() => handleEdit(question)}
                      style={{
                        padding: '8px 15px',
                        backgroundColor: '#3498db',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        marginRight: '8px'
                      }}
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(question.NO)}
                      style={{
                        padding: '8px 15px',
                        backgroundColor: '#e74c3c',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer'
                      }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
              {filteredQuestions.length === 0 && (
                <tr>
                  <td colSpan={5} style={{ padding: '30px', textAlign: 'center', color: '#7f8c8d' }}>
                    No questions found matching your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for Add/Edit */}
      {showModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.7)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '10px',
            width: '700px',
            maxHeight: '90vh',
            overflowY: 'auto'
          }}>
            <h3 style={{ marginTop: 0, color: '#2c3e50' }}>
              {editMode ? 'Edit Question' : 'Add New Question'}
            </h3>
            
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Standard:
                </label>
                <select
                  name="Standard_List"
                  value={formData.Standard_List}
                  onChange={handleChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                >
                  {standards.map(std => (
                    <option key={std.Standard_List} value={std.Standard_List}>
                      {std.Standard_List}
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Question Text:
                </label>
                <textarea
                  name="Question"
                  value={formData.Question}
                  onChange={handleChange}
                  required
                  rows={3}
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px',
                    fontFamily: 'inherit'
                  }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Option A:
                </label>
                <input
                  type="text"
                  name="Opt_A"
                  value={formData.Opt_A}
                  onChange={handleChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Option B:
                </label>
                <input
                  type="text"
                  name="Opt_B"
                  value={formData.Opt_B}
                  onChange={handleChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Option C:
                </label>
                <input
                  type="text"
                  name="Opt_C"
                  value={formData.Opt_C}
                  onChange={handleChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Option D:
                </label>
                <input
                  type="text"
                  name="Opt_D"
                  value={formData.Opt_D}
                  onChange={handleChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Correct Answer:
                </label>
                <select
                  name="Answer"
                  value={formData.Answer}
                  onChange={handleChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                >
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                  <option value="D">D</option>
                </select>
              </div>

              <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '25px' }}>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#95a5a6',
                    color: 'white',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    fontSize: '14px'
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#3498db',
                    color: 'white',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: 'bold'
                  }}
                >
                  {editMode ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuestionsAdminPage;
