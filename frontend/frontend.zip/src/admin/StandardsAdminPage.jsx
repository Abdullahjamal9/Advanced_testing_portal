import React, { useState, useEffect } from 'react';
import '../PTIS_App.css';

const StandardsAdminPage = ({ onBack }) => {
  const [standards, setStandards] = useState([]);
  const [infos, setInfos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentStandard, setCurrentStandard] = useState(null);
  
  const [formData, setFormData] = useState({
    Standard_List: '',
    Short_Name: '',
    Total_Questions: '',
    Passing_Criteria: '',
    Hours: '0',
    Minutes: '0',
    Seconds: '0'
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [standardsRes, infosRes] = await Promise.all([
        fetch('http://localhost:3001/api/standards'),
        fetch('http://localhost:3001/api/info')
      ]);
      
      const standardsData = await standardsRes.json();
      const infosData = await infosRes.json();
      
      setStandards(standardsData);
      setInfos(infosData);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Failed to load standards data');
      setLoading(false);
    }
  };

  const getInfoForStandard = (standardName) => {
    if (!Array.isArray(infos)) return null;
    return infos.find(info => info.Standard_List === standardName) || null;
  };

  const handleAdd = () => {
    setEditMode(false);
    setCurrentStandard(null);
    setFormData({
      Standard_List: '',
      Short_Name: '',
      Total_Questions: '',
      Passing_Criteria: '',
      Hours: '0',
      Minutes: '0',
      Seconds: '0'
    });
    setShowModal(true);
  };

  const handleEdit = (standard) => {
    setEditMode(true);
    setCurrentStandard(standard.Standard_List);
    const info = getInfoForStandard(standard.Standard_List);
    
    setFormData({
      Standard_List: standard.Standard_List,
      Short_Name: standard.Short_Name,
      Total_Questions: info?.Total_Questions || '',
      Passing_Criteria: info?.Passing_Criteria || '',
      Hours: info?.Hours || '0',
      Minutes: info?.Minutes || '0',
      Seconds: info?.Seconds || '0'
    });
    setShowModal(true);
  };

  const handleDelete = async (standardName) => {
    if (!window.confirm(`Are you sure you want to delete "${standardName}"? This will also delete its configuration.`)) {
      return;
    }

    try {
      // Delete both standard and info
      await Promise.all([
        fetch(`http://localhost:3001/api/standards/${encodeURIComponent(standardName)}`, {
          method: 'DELETE'
        }),
        fetch(`http://localhost:3001/api/info/${encodeURIComponent(standardName)}`, {
          method: 'DELETE'
        })
      ]);
      
      alert('Standard deleted successfully!');
      fetchData();
    } catch (error) {
      console.error('Error deleting standard:', error);
      alert('Failed to delete standard');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (editMode) {
        // Update both standard and info
        await Promise.all([
          fetch(`http://localhost:3001/api/standards/${encodeURIComponent(currentStandard)}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              Standard_List: formData.Standard_List,
              Short_Name: formData.Short_Name
            })
          }),
          fetch(`http://localhost:3001/api/info/${encodeURIComponent(currentStandard)}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              Standard_List: formData.Standard_List,
              Total_Questions: parseInt(formData.Total_Questions),
              Passing_Criteria: formData.Passing_Criteria,
              Hours: parseInt(formData.Hours),
              Minutes: parseInt(formData.Minutes),
              Seconds: parseInt(formData.Seconds)
            })
          })
        ]);
        alert('Standard updated successfully!');
      } else {
        // Create both standard and info
        await Promise.all([
          fetch('http://localhost:3001/api/standards', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              Standard_List: formData.Standard_List,
              Short_Name: formData.Short_Name
            })
          }),
          fetch('http://localhost:3001/api/info', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              Standard_List: formData.Standard_List,
              Total_Questions: parseInt(formData.Total_Questions),
              Passing_Criteria: formData.Passing_Criteria,
              Hours: parseInt(formData.Hours),
              Minutes: parseInt(formData.Minutes),
              Seconds: parseInt(formData.Seconds)
            })
          })
        ]);
        alert('Standard created successfully!');
      }

      setShowModal(false);
      fetchData();
    } catch (error) {
      console.error('Error saving standard:', error);
      alert('Failed to save standard');
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (loading) {
    return <div style={{ padding: '50px', textAlign: 'center' }}>Loading standards...</div>;
  }

  return (
    <div style={{ padding: '30px', maxWidth: '1200px', margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
          <button
            onClick={onBack}
            style={{
              padding: '10px 20px',
              backgroundColor: '#3498db',
              color: 'white',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold'
            }}
          >
            ← Back
          </button>
          <h2 style={{ margin: 0, color: '#2c3e50' }}>Standards Management</h2>
        </div>
        <button
          onClick={handleAdd}
          style={{
            padding: '12px 25px',
            backgroundColor: '#3498db',
            color: 'white',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            fontSize: '16px',
            fontWeight: 'bold'
          }}
        >
          + Add New Standard
        </button>
      </div>

      <div style={{ backgroundColor: '#ecf0f1', padding: '20px', borderRadius: '10px' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', backgroundColor: 'white' }}>
          <thead>
            <tr style={{ backgroundColor: '#34495e', color: 'white' }}>
              <th style={{ padding: '15px', textAlign: 'left', border: '1px solid #bdc3c7' }}>Standard Name</th>
              <th style={{ padding: '15px', textAlign: 'left', border: '1px solid #bdc3c7' }}>Short Name</th>
              <th style={{ padding: '15px', textAlign: 'left', border: '1px solid #bdc3c7' }}>Total Questions</th>
              <th style={{ padding: '15px', textAlign: 'left', border: '1px solid #bdc3c7' }}>Passing Criteria</th>
              <th style={{ padding: '15px', textAlign: 'left', border: '1px solid #bdc3c7' }}>Time Limit</th>
              <th style={{ padding: '15px', textAlign: 'center', border: '1px solid #bdc3c7' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {standards.map((standard, index) => {
              const info = getInfoForStandard(standard.Standard_List);
              return (
                <tr key={index} style={{ borderBottom: '1px solid #bdc3c7' }}>
                  <td style={{ padding: '12px', border: '1px solid #bdc3c7' }}>{standard.Standard_List}</td>
                  <td style={{ padding: '12px', border: '1px solid #bdc3c7' }}>{standard.Short_Name}</td>
                  <td style={{ padding: '12px', border: '1px solid #bdc3c7' }}>
                    {info ? info.Total_Questions : 'N/A'}
                  </td>
                  <td style={{ padding: '12px', border: '1px solid #bdc3c7' }}>
                    {info ? info.Passing_Criteria : 'N/A'}
                  </td>
                  <td style={{ padding: '12px', border: '1px solid #bdc3c7' }}>
                    {info ? `${info.Hours}h ${info.Minutes}m ${info.Seconds}s` : 'N/A'}
                  </td>
                  <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #bdc3c7' }}>
                    <button
                      onClick={() => handleEdit(standard)}
                      style={{
                        padding: '8px 15px',
                        backgroundColor: '#3498db',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        marginRight: '8px'
                      }}
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(standard.Standard_List)}
                      style={{
                        padding: '8px 15px',
                        backgroundColor: '#e74c3c',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer'
                      }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Modal for Add/Edit */}
      {showModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.7)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '10px',
            width: '600px',
            maxHeight: '90vh',
            overflowY: 'auto'
          }}>
            <h3 style={{ marginTop: 0, color: '#2c3e50' }}>
              {editMode ? 'Edit Standard' : 'Add New Standard'}
            </h3>
            
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Standard Name:
                </label>
                <input
                  type="text"
                  name="Standard_List"
                  value={formData.Standard_List}
                  onChange={handleChange}
                  required
                  disabled={editMode}
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Short Name:
                </label>
                <input
                  type="text"
                  name="Short_Name"
                  value={formData.Short_Name}
                  onChange={handleChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Total Questions:
                </label>
                <input
                  type="number"
                  name="Total_Questions"
                  value={formData.Total_Questions}
                  onChange={handleChange}
                  required
                  min="1"
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Passing Criteria (e.g., 70%):
                </label>
                <input
                  type="text"
                  name="Passing_Criteria"
                  value={formData.Passing_Criteria}
                  onChange={handleChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #bdc3c7',
                    borderRadius: '5px',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Time Limit:
                </label>
                <div style={{ display: 'flex', gap: '10px' }}>
                  <div style={{ flex: 1 }}>
                    <label style={{ fontSize: '12px', color: '#7f8c8d' }}>Hours</label>
                    <input
                      type="number"
                      name="Hours"
                      value={formData.Hours}
                      onChange={handleChange}
                      min="0"
                      style={{
                        width: '100%',
                        padding: '10px',
                        border: '1px solid #bdc3c7',
                        borderRadius: '5px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <div style={{ flex: 1 }}>
                    <label style={{ fontSize: '12px', color: '#7f8c8d' }}>Minutes</label>
                    <input
                      type="number"
                      name="Minutes"
                      value={formData.Minutes}
                      onChange={handleChange}
                      min="0"
                      max="59"
                      style={{
                        width: '100%',
                        padding: '10px',
                        border: '1px solid #bdc3c7',
                        borderRadius: '5px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <div style={{ flex: 1 }}>
                    <label style={{ fontSize: '12px', color: '#7f8c8d' }}>Seconds</label>
                    <input
                      type="number"
                      name="Seconds"
                      value={formData.Seconds}
                      onChange={handleChange}
                      min="0"
                      max="59"
                      style={{
                        width: '100%',
                        padding: '10px',
                        border: '1px solid #bdc3c7',
                        borderRadius: '5px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '25px' }}>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#95a5a6',
                    color: 'white',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    fontSize: '14px'
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#3498db',
                    color: 'white',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: 'bold'
                  }}
                >
                  {editMode ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StandardsAdminPage;
