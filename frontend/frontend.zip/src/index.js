import React from 'react';
import ReactDOM from 'react-dom/client';
import TestingModule from './TestingModule';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <TestingModule />
  </React.StrictMode>
);
